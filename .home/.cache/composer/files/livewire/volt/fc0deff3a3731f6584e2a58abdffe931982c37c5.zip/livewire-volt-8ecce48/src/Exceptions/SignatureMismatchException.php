<?php

namespace Livewire\Volt\Exceptions;

use RuntimeException;

class SignatureMismatchException extends RuntimeException
{
    //
}
