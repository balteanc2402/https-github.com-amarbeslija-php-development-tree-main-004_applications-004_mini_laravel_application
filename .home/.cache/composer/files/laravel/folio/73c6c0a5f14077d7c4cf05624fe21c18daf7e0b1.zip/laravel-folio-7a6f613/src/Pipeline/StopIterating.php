<?php

namespace Laravel\Folio\Pipeline;

class StopIterating
{
    //
}
